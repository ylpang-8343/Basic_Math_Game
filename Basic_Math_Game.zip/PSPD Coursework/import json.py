import json
import os

def load_scores():
    """Load scores from a JSON file."""
    if os.path.exists("scores.json"):
        with open("scores.json", "r") as f:
            return json.load(f)
    return {}

def save_score(username, score):
    """Save the highest score for a user."""
    scores = load_scores()
    scores[username] = max(scores.get(username, 0), score)
    with open("scores.json", "w") as f:
        json.dump(scores, f)

def get_rankings():
    """Return a sorted list of users and scores."""
    scores = load_scores()
    return sorted(scores.items(), key=lambda x: x[1], reverse=True)
