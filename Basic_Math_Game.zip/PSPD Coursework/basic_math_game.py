# *************************************************************************
# Program: basic_math_game.py
# Course: CSP1114 PROBLEM SOLVING AND PROGRAM DESIGN
# Lecture / Lab Section: TC2L / TL6L
# Trimester: 2430
# Names: CHEE WEI KEONG | ONG JUN ZE | PANG YOKE LEAP
# IDs: 242FC242F0 | 242FC242FD | 242FC241J1
# Emails: CHEE.WEI.KEONG@student.mmu.edu.my | ONG.JUN.ZE@student.mmu.edu.my | PANG.YOKE.LEAP@student.mmu.edu.my
# *************************************************************************

import pygame
import random
import json
import os
import datetime

# Initialise pygame
pygame.init()

# Screen Settings
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("BASIC MATH GAME")

# Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (6,32,134)

# Fonts
title_font = pygame.font.Font(None, 64)
font = pygame.font.Font(None, 36)

# Load sounds
pygame.mixer.music.load("background_music.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)

# Load sound effects
tick_sound = pygame.mixer.Sound("tick.wav")
correct_sound = pygame.mixer.Sound("correct.wav")
wrong_sound = pygame.mixer.Sound("wrong.wav")
victory_sound = pygame.mixer.Sound("victory.wav")
gameover_sound = pygame.mixer.Sound("gameover.wav")

def play_sound(sound):
    pygame.mixer.Sound.play(sound)

# Load images
background_img = pygame.image.load("background.png")
mainmenu_img = pygame.image.load("mainmenu.png")
player_img = pygame.image.load("player.png")
monster_img = pygame.image.load("monster.png")
quiz_img = pygame.image.load("quiz.png")
victory_img = pygame.image.load("victory.png")
gameover_img = pygame.image.load("gameover.png")
storyline_img = pygame.image.load("storyline.png")

def draw_characters(player_x, player_y):
    screen.blit(player_img, (player_x, player_y))
    screen.blit(monster_img, (600, 300))  # Monster remains stationary

# Game states
MAIN_MENU, USERNAME_INPUT, STORYLINE, PLAYING, QUIZ, GAME_OVER, VICTORY, PAUSE_MENU, RANKINGS = range(9)
state = MAIN_MENU

# Feedback
feedback = ""

# Player Stats
username = ""
score = 0
player_health = 3  # 3 chances
player_x, player_y = 100, 300
player_speed = 5

# Monster stats
monster_health = 100

#Question variables
current_question = ""
correct_answer = 0
user_answer = ""
question_count = 0
question_list = []

# Load and save functions
def load_scores():
    """Load scores from a JSON file."""
    if os.path.exists("scores.json"):
        try:
            with open("scores.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError:
            # if file broken/empty, return{}
            return {}
    return {}

def save_score(name, score):
    """Save the highest score for a user."""
    scores = load_scores()
    if name not in scores:
        scores[name] = {"highest_score": score, "last_score": score, "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    else:
        scores[name]["highest_score"] = max(scores[name]["highest_score"], score)
        scores[name]["last_score"] = score
        scores[name]["timestamp"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    try:
        with open("scores.json", "w", encoding="utf-8") as f:
            json.dump(scores, f, ensure_ascii=False, indent=4)
    except IOError:
        print("Error: Unable to save scores.")

def generate_questions():
    global question_list, question_count
    question_list = []
    operators = ['+', '-', '*', '/']
    
    # generate easy questions (numbers 1-10)
    
    for op in operators:
        for _ in range(1):
            num1, num2 = random.randint(1, 10), random.randint(1, 10)
            question_list.append((num1, op, num2, eval(f"{num1} {op} {num2}"), 5)) # easy question get 5 mrks
    
    # generate medium questions (numbers 10-20)
    
    for op in operators:
        for _ in range(1):
            num1, num2 = random.randint(10, 20), random.randint(1, 10)
            question_list.append((num1, op, num2, eval(f"{num1} {op} {num2}"), 10)) # medium question get 10 marks
    
    # generate difficult questions (numbers 20-30)
    
    for op in operators:
        for _ in range(1):
            num1, num2 = random.randint(20, 30), random.randint(1, 10)
            question_list.append((num1, op, num2, eval(f"{num1} {op} {num2}"), 15)) # difficult questions get 15 marks
    
    # order question difficulty
    
    question_count = 0 # reset question count

def next_question():
    global current_question, correct_answer, question_count, state, score, player_health, feedback
    print(f"Next Question: question_count = {question_count}, total_questions= {question_list}") # debug
    if question_count < len(question_list):
        num1, op, num2, answer, points = question_list[question_count]
        correct_answer = answer
        current_question = f"{num1} {op} {num2} = ?"
        question_count += 1
    else:
        state = VICTORY
        feedback = ""
        print("All questions anwered. Switching to Victory state...") # debug
    

def reset_game():
    """Reset game variables for a new run."""
    global player_health, monster_health, score, state, user_answer, question_count
    player_health = 3
    monster_health = 100
    score = 0
    user_answer = ""
    state = MAIN_MENU
    generate_questions()
    question_count = 0

generate_questions()
next_question()

# Game loop
clock = pygame.time.Clock()
running = True
played_sound = False
while running:
    screen.blit(background_img, (0, 0))
    print(f"Current state: {state}") # debug

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            if state in [PLAYING, QUIZ, GAME_OVER, VICTORY]:
                save_score(username, score)
            running = False
            
        if event.type == pygame.KEYDOWN:
            if state == MAIN_MENU:
                if event.key == pygame.K_RETURN:
                    play_sound(tick_sound)
                    state = USERNAME_INPUT
                elif event.key == pygame.K_r:
                    play_sound(tick_sound)
                    state = RANKINGS
                elif event.key == pygame.K_ESCAPE:
                    running = False
            elif state == RANKINGS:
                if event.key == pygame.K_ESCAPE:
                    state = MAIN_MENU
            elif state == USERNAME_INPUT:
                if event.key == pygame.K_RETURN and username:
                    state = STORYLINE
                elif event.key == pygame.K_BACKSPACE:
                    username = username[:-1]
                elif event.key == pygame.K_ESCAPE:
                    state = MAIN_MENU
                else:
                    username += event.unicode
            elif state == STORYLINE:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    state = PLAYING
            elif state == PLAYING:
                if event.key == pygame.K_ESCAPE:
                    state = PAUSE_MENU
                elif player_rect.colliderect(monster_rect) and state != QUIZ:
                    # Trigger the quiz if the player collides with the monster
                    state = QUIZ
            elif state == QUIZ:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE: # Open pause menu
                        state = PAUSE_MENU
                        print("Changing to pause menu...") # debug
                    elif event.key == pygame.K_RETURN:
                        try:
                            user_answer_float = float(user_answer)  # make input to integer
                            if abs(user_answer_float - correct_answer) < 0.0001:
                                play_sound(correct_sound)
                                score += question_list[question_count - 1][4]  # adjust marks according to difficulty
                                feedback = "Congrats! You attacked the monster!"
                                next_question()
                                if score >= 100: # check if score is 100
                                    state = VICTORY
                                    print("All questions answered. Switching to Victory state...") #debug
                                    continue
                            else:
                                play_sound(wrong_sound)
                                player_health -= 1
                                feedback = f"Oh no! You were attacked. The correct answer was {correct_answer}"
                                next_question()
                                user_answer = ""
                                if player_health <= 0: # check if health is 0
                                    state = GAME_OVER
                                    print("player health is 0. switching to game over state...") # debug
                                    continue
                                else:
                                    generate_questions()
                                    state = PLAYING
                            user_answer = ""
                        except ValueError:
                            # if not integer give feedback
                            feedback = "Invalid input! Please enter a number."
                            play_sound(wrong_sound)
                    elif event.key == pygame.K_BACKSPACE:
                        user_answer = user_answer[:-1]
                    else:
                        user_answer += event.unicode
                        
            elif state == GAME_OVER:
                play_sound(gameover_sound)
                if event.key == pygame.K_r:
                    save_score(username,score)
                    reset_game()
            elif state == VICTORY:
                play_sound(victory_sound)
                played_sound = True
                if event.key == pygame.K_r:
                    save_score(username,score)
                    reset_game()
                    
            elif state == PAUSE_MENU:
                if event.type == pygame.KEYDOWN:    
                    if event.key == pygame.K_ESCAPE:
                        state = PLAYING
                    elif event.key == pygame.K_q:
                        state = MAIN_MENU
                    elif event.key == pygame.K_r:
                        reset_game()
                        state = MAIN_MENU

    # Player Movement (WASD keys)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:  # Move left
        player_x -= player_speed
    if keys[pygame.K_d]:  # Move right
        player_x += player_speed
    if keys[pygame.K_w]:  # Move up
        player_y -= player_speed
    if keys[pygame.K_s]:  # Move down
        player_y += player_speed

    # Prevent going out of bounds (screen limits)
    if player_x < 0:
        player_x = 0  # Prevent going off the left side
    if player_x > SCREEN_WIDTH - player_img.get_width():
        player_x = SCREEN_WIDTH - player_img.get_width()  # Prevent going off the right side
    if player_y < 0:
        player_y = 0  # Prevent going off the top side
    if player_y > SCREEN_HEIGHT - player_img.get_height():
        player_y = SCREEN_HEIGHT - player_img.get_height()  # Prevent going off the bottom side

    # Check if player collides with monster
    player_rect = pygame.Rect(player_x, player_y, player_img.get_width(), player_img.get_height())
    monster_rect = pygame.Rect(600, 300, monster_img.get_width(), monster_img.get_height())
    
    

    if state == MAIN_MENU:
        screen.blit(mainmenu_img, (0,0))
        title_text = title_font.render("BASIC MATH GAME", True, BLACK)
        screen.blit(title_text, (SCREEN_WIDTH//2 - 220, SCREEN_HEIGHT//2 - 50))
        instruction_text = font.render("Press: [Enter] Start   [R] Rankings   [Esc] Exit", True, BLACK)
        screen.blit(instruction_text, (SCREEN_WIDTH//2 - 250, SCREEN_HEIGHT//2 + 20))

        # Ban player movement
        player_x, player_y = 100, 300 # make player position constant
        draw_characters(player_x, player_y)

    elif state == USERNAME_INPUT:
        screen.blit(mainmenu_img, (0,0))
        input_text = font.render(f"Enter Username: {username}", True, BLACK)
        screen.blit(input_text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2))
        menu_text = font.render("[Esc] Menu", True, BLACK)
        screen.blit(menu_text, (20, 20))

        # Ban player movement
        player_x, player_y = 100, 300 # make player position constant
        draw_characters(player_x, player_y)

    elif state == STORYLINE:
        screen.blit(storyline_img, (0,0))
        story_text = [
            "Long time ago, in the Land of Mondstadt. ",
            "There is a kingdom named the kingdom of Math. ",
            "In the kingdom everyone is living happily because its peaceful. ",
            "But these peaceful days lasted until an appearance of a dragon. ",
            "The monster destroyed parts of kingdom and created chaos. ",
            "Now, the kingdom needs you the prince to save the kingdom. ",
            "Can you defeat the monster and restore peace? ",
            "Press Enter to start."
            ]
        for i, line in enumerate(story_text):
            text = font.render(line, True, BLACK)
            screen.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, 150 + i * 40))

    elif state == PLAYING:
        menu_text = font.render("[ESC] Menu", True, BLACK)
        screen.blit(menu_text, (20, 20))
        instruction_text = font.render("Defeat the monster!", True, RED)
        screen.blit(instruction_text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2 - 50))
        health_text = font.render("O" * player_health, True, RED)
        screen.blit(health_text, (SCREEN_WIDTH//2 - 40, 20))
        score_text = font.render(f"Score: {score}/100", True, BLACK)
        screen.blit(score_text, (SCREEN_WIDTH - 150, 20))
        draw_characters(player_x, player_y)
        

    elif state == QUIZ:
        screen.blit(quiz_img, (0,0))
        menu_text = font.render("[ESC] Menu", True, BLACK)
        screen.blit(menu_text, (20, 20))
        question_text = font.render(f"Question: {current_question}", True, BLACK)
        answer_text = font.render(f"Your Answer: {user_answer}", True, BLUE)
        feedback_text = font.render(feedback, True, RED if "Oh no" in feedback else GREEN)
        screen.blit(question_text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2 - 50))
        screen.blit(answer_text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2))
        screen.blit(feedback_text, (SCREEN_WIDTH//2 - 300, SCREEN_HEIGHT//2 + 50))
        health_text = font.render("O" * player_health, True, RED)
        screen.blit(health_text, (SCREEN_WIDTH//2 - 40, 20))
        score_text = font.render(f"Score: {score}/100", True, BLACK)
        screen.blit(score_text, (SCREEN_WIDTH - 150, 20))

        player_x, player_y = 100, 300

    elif state == VICTORY:
        screen.blit(victory_img, (0,0))
        text = font.render("You Win! Press R to Restart", True, GREEN)
        screen.blit(text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2))
        play_sound(victory_sound)

    elif state == GAME_OVER:
        screen.blit(gameover_img, (0,0))
        text = font.render("Game Over! Press R to Restart", True, RED)
        screen.blit(text, (SCREEN_WIDTH//2 - 150, SCREEN_HEIGHT//2))
        play_sound(gameover_sound)

    elif state == PAUSE_MENU:
        menu_options = ["Resume [ESC]", "Restart [R]", "Quit to Main Menu [Q]"]
        for i, option in enumerate(menu_options):
            text = font.render(option, True, BLACK)
            screen.blit(text, (20, 50 + i * 30))
            
    elif state == RANKINGS:
        screen.blit(mainmenu_img, (0,0))
        menu_text = font.render("[Esc] Menu", True, BLACK)
        screen.blit(menu_text, (20, 20))
        scores = load_scores()
        y_offset = 100
        for name, data in sorted(scores.items(), key=lambda x: x[1]["highest_score"], reverse=True):
            rank_text = font.render(f"{name}: Highest Score: {data['highest_score']}, Last Score: {data['last_score']}, Time: {data['timestamp']}", True, BLACK)
            screen.blit(rank_text, (SCREEN_WIDTH//2 - 400, y_offset))
            y_offset += 30
        
        # Ban player movement
        player_x, player_y = 100, 300 # make player position constant
        draw_characters(player_x, player_y)
    
    # Draw player and monster characters
    
    
    pygame.display.flip()
    clock.tick(60)

pygame.quit()